export default function Loading() {
  return (
    <p className="text-center mt-10 dark:bg-transparent dark:text-white">
      Loading...
    </p>
  );
}
